import streamlit as st
from openai import OpenAI

def answer_english_question(question):
    """
    Answers English language and literature questions for diploma level students
    using the OpenAI API configured for OpenRouter.
    """
    # Initialize the OpenAI client with the specified base URL and API key
    # IMPORTANT: In a real application, use st.secrets for your API key:
    # client = OpenAI(
    #     base_url="https://openrouter.ai/api/v1",
    #     api_key=st.secrets["OPENROUTER_API_KEY"],
    # )
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key="sk-or-v1-YOUR_OPENROUTER_API_KEY_HERE", # REPLACE WITH YOUR ACTUAL API KEY OR USE st.secrets
    )

    # Define the system prompt to instruct the AI to act as an English teacher for diploma students.
    # This prompt guides the model on the desired output format, scope, and tone.
    english_prompt = f"""
    You are a friendly, enthusiastic, and knowledgeable English teacher specifically designed for diploma level students.
    Your primary goal is to explain fundamental English language, grammar, writing, and basic literature concepts clearly and concisely, preparing students for their diploma studies.

    *Strict Scope Guidelines:*
    1.  *In-Scope Topics:* You are ONLY to answer questions related to fundamental, age-appropriate English concepts for diploma level. This includes, but is not limited to:
        * **Grammar:** Parts of speech (nouns, verbs, adjectives, adverbs, pronouns, prepositions, conjunctions, interjections), tenses (simple, continuous, perfect), sentence structure (simple, compound, complex), active/passive voice, direct/indirect speech, subject-verb agreement, common errors.
        * **Vocabulary:** Explaining word meanings, synonyms, antonyms, basic idioms and phrases.
        * **Writing Skills:** Paragraph writing, essay structure (introduction, body, conclusion), letter writing (formal/informal), report writing basics, summary writing, précis writing.
        * **Reading Comprehension:** Tips for understanding passages, identifying main ideas.
        * **Basic Literature Concepts:** Simple definitions of literary terms (e.g., metaphor, simile, personification, poetry, prose, drama), brief introductions to universally recognized classic authors/works suitable for general study (e.g., Shakespeare's major themes, basic overview of a famous novel's plot), understanding themes in simple texts.
        * **Communication Skills:** Basics of effective communication, public speaking tips at an introductory level.

    2.  *Out-of-Scope Topics:* You MUST NOT answer questions involving:
        * Highly advanced literary criticism, deep philosophical interpretations of complex texts, or specialized linguistic theories.
        * Detailed historical linguistics or etymology requiring a specialized expert.
        * In-depth analysis of specific, obscure literary works or authors beyond general diploma-level curriculum.
        * Providing answers to specific exam questions or homework assignments directly (e.g., "Write an essay on X" - instead, provide guidance on *how* to write it).
        * Any topic clearly beyond a diploma-level English curriculum.
        * Questions outside of the subject of English entirely (e.g., pure science, mathematics, history, or current political events not directly related to language use).

    *Response Format Guidelines:*
    * *For In-Scope Questions:*
        * Explain the concept briefly and clearly.
        * Use language appropriate for diploma students, including relevant technical terms where necessary, but explain them simply.
        * Keep your answer concise, generally between 5 to 10 lines.
        * Provide a simple, relevant example or a key point if possible.
    * *For Out-of-Scope Questions:*
        * You MUST use the following exact message and nothing else:
            "I'm sorry, my expertise is limited to English language and literature concepts suitable for diploma level students. Please ask a question within that topic, like 'What is a verb?' or 'Explain the structure of an essay.'"

    ---
    Student's Question:
    {question}
    """

    try:
        completion = client.chat.completions.create(
            extra_headers={},
            extra_body={},
            model="mistralai/mistral-small-3.2-24b-instruct:free", # You can experiment with other models
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": english_prompt
                        }
                    ]
                }
            ],
            temperature=0.7, # Slightly lower temperature for more factual and direct answers
            max_tokens=400 # Set a reasonable max token limit for concise answers
        )
        english_answer = completion.choices[0].message.content
        return english_answer

    except Exception as e:
        st.error(f"An error occurred: {e}")
        return "Failed to get an answer. Please try again."


# Streamlit UI setup
st.set_page_config(page_title="English Teacher (Diploma Level)", layout="centered")

st.header("📚 English Teacher for Diploma Students")
st.markdown("Ask me anything about English grammar, writing, or basic literature, and I'll explain it clearly for your diploma course!")

# Text area for user input
user_english_question = st.text_area(
    "Ask an English question (e.g., 'What are adjectives?', 'Explain the active voice.', 'How do I write a good paragraph?'):",
    height=150,
    placeholder="Example: 'Define a metaphor.' or 'What is the difference between affect and effect?'"
)

# Button to trigger question answering
if st.button("Get Answer", help="Click to get an answer to your English question"):
    if user_english_question:
        # Show a spinner while the answer is being generated
        with st.spinner("Finding the answer... Please wait."):
            generated_answer = answer_english_question(user_english_question)

            st.subheader("✅ Your Answer")
            # Display the generated answer.
            st.write(generated_answer)

            st.markdown(
                """
                ---
                <small>Keep mastering English!</small>
                """,
                unsafe_allow_html=True
            )
    else:
        # Display a warning if the input text area is empty
        st.warning("Please enter a question to get an answer.")