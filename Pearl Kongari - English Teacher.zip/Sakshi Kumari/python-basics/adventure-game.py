# Your own adventure game that is basically a story driven game. Choose your own story
# Choose your own adventure
name = input("Type your name: ")
print(f"Welcome {name.title()} to this adventure!")

answer = input("You are on a dirt road, it has come to an end and you can go left or right. Which way would you like to go? ")

if answer.lower() == "left":
    answer = input("You came to a river, you can walk around it or swim across? Type walk to walk around or swim to swim across: ")

    if answer.lower() == "swim":
        print("You swam across and were eaten by an alligator.")
    elif answer.lower() == "walk":
        print("You walk for many miles, ran out of water and you lost the game.")
    else:
        print("Not a valid option. You lose.")  

elif answer.lower() == "right":
    answer = input("You came to a bridge, it looks wobbly, do you want to cross it or head back (cross/back)? ")
    if answer.lower() == "back":
        print("You go back and you lose.")

    elif answer.lower() == "cross":
        answer = input("You cross the bridge and met a stranger. Do you talk to them (yes/no)? ")

        if answer.lower() == "yes":
            print("You talk to the stranger and the stranger gave you the treasure map. You won!")
        elif answer.lower() == "no":
            print("You ignored the stranger and the stranger gets upset and shoot you. And you die!")
        else:
            print("Not a valid option. You lose.")
    
    else:
        print("Not a valid option. You lose.")
else:
    print("Not a valid option. You lose.")

print(f"Thanks for playing! {name.title()}")