# A Quiz Game - You can choose your own set of questions.
# Quiz game
print("Welcome to my computer quiz!")

playing = input("Do you want to play? ")

if playing.lower() != "yes":
    quit()

print("Okay! Let's play :)")
score = 0

answer = input("What does CPU stands for? ")

if answer.lower() == "central processing unit":
    print('Correct!')
    score += 1 # score += 1 => score = score + 1
else:
    print('Incorrect!')

answer = input("What does GPU stands for? ")

if answer.lower() == "graphics processing unit":
    print('Correct!')
    score += 1
else:
    print('Incorrect!')

answer = input("What does RAM stands for? ")

if answer.lower() == "random access memory":
    print('Correct!')
    score += 1
else:
    print('Incorrect!')

answer = input("What does ROM stands for? ")

if answer.lower() == "read only memory":
    print('Correct!')
    score += 1
else:
    print('Incorrect!')

print(f"You got {score} questions correct!")
print(f"You got {(score / 4) * 100} %.")