import streamlit as st
from openai import OpenAI

def generate_poem(keywords_or_sentence, length_preference="medium"):
    """
    Generates an English poem using the OpenAI API configured for OpenRouter,
    based on provided keywords or a sentence.
    """
    # Initialize the OpenAI client with the specified base URL and API key
    # IMPORTANT: In a real application, use st.secrets for your API key:
    # client = OpenAI(
    #     base_url="https://openrouter.ai/api/v1",
    #     api_key=st.secrets["OPENROUTER_API_KEY"],
    # )
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key="YOUR_OPENROUTER_API_KEY_HERE", # REPLACE WITH YOUR ACTUAL API KEY OR USE st.secrets
    )

    # Determine desired poem length based on user preference
    if length_preference == "short":
        length_guidance = "2-3 stanzas, 8-12 lines"
    elif length_preference == "long":
        length_guidance = "5-7 stanzas, 20-30 lines"
    else: # medium
        length_guidance = "3-5 stanzas, 12-20 lines"


    # Define the system prompt to instruct the AI to act as a poet.
    # This prompt guides the model on the desired output format, style, and tone.
    poem_prompt = f"""
    You are a creative and expressive English poet. Your task is to compose a beautiful and evocative poem
    based on the given keywords or sentence.

    *Poem Guidelines:*
    - The poem should be in English.
    - It should aim for a lyrical and imaginative style.
    - Focus on imagery, metaphors, and sensory details related to the input.
    - You can use any poetic form (free verse is often good, but feel free to use rhyme and rhythm naturally).
    - The poem should be approximately {length_guidance}.
    - Ensure the poem has a clear beginning, middle, and end, telling a small story or evoking a specific feeling.

    ---
    Keywords/Sentence for the poem:
    "{keywords_or_sentence}"
    """

    try:
        completion = client.chat.completions.create(
            extra_headers={},
            extra_body={},
            model="mistralai/mistral-small-3.2-24b-instruct:free", # You can experiment with other models
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": poem_prompt
                        }
                    ]
                }
            ],
            temperature=0.8, # Higher temperature for more creativity
            max_tokens=500 # Set a reasonable max token limit for poems
        )
        poem_text = completion.choices[0].message.content
        return poem_text

    except Exception as e:
        st.error(f"An error occurred: {e}")
        return "Failed to generate a poem. Please try again."


# Streamlit UI setup
st.set_page_config(page_title="English Poem Generator", layout="centered")

st.header("✍️ English Poem Generator")
st.markdown("Enter keywords or a sentence, and I'll conjure a poem for you!")

# Text area for user input
user_input = st.text_area(
    "Enter keywords (e.g., 'sunset, ocean, dreams') or a sentence (e.g., 'The old clock ticks softly in the hall.'):",
    height=100,
    placeholder="Example: 'whispering leaves, autumn breeze' or 'a forgotten library on a rainy day'"
)

# Slider for poem length preference
length_option = st.radio(
    "Choose poem length preference:",
    ('Short (8-12 lines)', 'Medium (12-20 lines)', 'Long (20-30 lines)'),
    index=1 # Medium by default
)

# Convert display text to internal value
if "Short" in length_option:
    selected_length = "short"
elif "Long" in length_option:
    selected_length = "long"
else:
    selected_length = "medium"

# Button to trigger poem generation
if st.button("Generate Poem 🖋️", help="Click to generate your poem"):
    if user_input:
        with st.spinner("Crafting your poem... Please wait."):
            generated_poem = generate_poem(user_input, selected_length)

            st.subheader("📜 Your Poem")
            st.write(generated_poem)

            st.markdown(
                """
                ---
                <small>Hope you enjoyed your AI-generated verse!</small>
                """,
                unsafe_allow_html=True
            )
    else:
        st.warning("Please enter some keywords or a sentence to generate a poem.")