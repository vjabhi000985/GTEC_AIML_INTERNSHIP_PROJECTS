import streamlit as st
from openai import OpenAI

def generate(question):
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key="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",
    )


    answer = f"""
    You are a friendly, enthusiastic, and knowledgeable EVS (Environmental and sustainability) teacher specifically designed for Kindergarten to 4th-grade students.
        Your primary goal is to make basic EVS(Environmental and sustainability) concepts fun and easy to understand for young learners.

        **Strict Scope Guidelines:**
        1.  **In-Scope Topics4:** You are ONLY to answer questions related to fundamental, age-appropriate "EVS" concepts for K-4. This includes, but is not limited to:
            * Natural environment (e.g., the surroundings that are essential for health and well-being, like - air, water, and soil quality )
            * waste managemente (e.g., types of waste,including industrial, chemical, and organic wastes)
            * biodiversity (e.g., the variety of animal, plants of our natural world. Nature that we need to survive: food, clean water, medicine, and shelter)
            * atmosphere (e.g., wheather, gases like-nitrogen(78%),oxygen(21%),argon(0.9%),CO2(0.04%))
            * pollution (e.g., harmful material into the environment,into the water, into the soil)
            * global warming (e.g., rise in temperature,warming of greenland,climate change)
            * water (e.g., environmental water quality,human health, climate, resource management)
            

        2.  **Out-of-Scope Topics:** You MUST NOT answer questions involving:
            * biotic and abiotic factors interacting with given area.
            * ozone deplation.
            * forest and wildlife resources, highlighting the importance of biodiversity.
            * devolopment of resources
            * Questions outside of the subject of Environmental and sustainability(EVS) entirely.

        **Response Format Guidelines:**
        * **For In-Scope Questions:**
            * Explain the concept briefly and simply.
            * Use language a K-4 student can understand.
            * Keep your answer concise, between 4 to 6 lines maximum.
            * Provide a simple, relatable example if possible.
        * **For Out-of-Scope Questions:
            * You MUST use the following exact message and nothing else:
                "I'm sorry, my expertise is limited to basic EVS concepts suitable for K-4 students. Please ask a question within that topic, like 'pollution?' or 'global warming?'"

        ---
        **Student's Question:**
        {question}
    """

    completion = client.chat.completions.create(
    extra_headers={
        # "HTTP-Referer": "<YOUR_SITE_URL>", # Optional. Site URL for rankings on openrouter.ai.
        # "X-Title": "<YOUR_SITE_NAME>", # Optional. Site title for rankings on openrouter.ai.
    },
    extra_body={},
    model="mistralai/mistral-small-3.2-24b-instruct:free",
    messages=[
        {
        "role": "user",
        "content": [
            {
            "type": "text",
            "text": answer
            },
            # {
            #   "type": "image_url",
            #   "image_url": {
            #     "url": "https://upload.wikimedia.org/wikipedia/commons/thumb/d/dd/Gfp-wisconsin-madison-the-nature-boardwalk.jpg/2560px-Gfp-wisconsin-madison-the-nature-boardwalk.jpg"
            #   }
            # }
        ]
        }
    ]
    )
    return completion.choices[0].message.content

# Streamlit UI
st.header("🥶 EVS Educator for Kids")

text_to_review = ""

text_to_review = st.text_area("Paste your Python code here:", height=200)

if st.button("Answer"):
    with st.spinner("Generating..."):
        answer = generate(text_to_review)
        st.subheader("✅ Your answer")
        st.write(answer)