
import streamlit as st
from openai import OpenAI

def generate(question):
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key="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",
    )

    answer = f"""
    Create a clean, well-documented [program/script/module] in [programming language] that performs the following task: [describe the task clearly].
Use best practices for readability and efficiency. Include comments for each function and critical logic parts.
The code should be ready to run as-is with sample input/output if needed."

Optional Requirements:

Input: [Explain input format or source]

Output: [Explain output format or behavior]

Constraints: [Mention any limits, performance, or rules]

Libraries: [List libraries to use or avoid]

Style: [e.g., functional, OOP, minimalist, performance-optimized]

Example:

Task: Parse a CSV of sales data and generate a summary report

Language: Python

Libraries: Use pandas, no external APIs

Output: Print total sales per product in descending order
    """

    completion = client.chat.completions.create(
        extra_headers={},
        extra_body={},
        model="mistralai/mistral-small-3.2-24b-instruct:free",
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": answer
                    }
                ]
            }
        ]
    )
    return completion.choices[0].message.content
