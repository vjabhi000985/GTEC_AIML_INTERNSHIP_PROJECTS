import random

user_wins = 0
computer_wins = 0

while True:
    # Player section.
    user_input = input("Type 1-Rock/2-Paper/3-Scissors or Q to quit: ")

    if user_input.lower() == "q":
        break
    
    if int(user_input) == 1:
        user_choice = "rock"
    elif int(user_input) == 2:
        user_choice = "paper"
    elif int(user_input) == 3:
        user_choice = "scissors"
    else:
        print("Please enter a valid choice!")
        continue
    
    # Computer section
    computer_input = random.randint(1,3)

    if computer_input == 1:
        computer_choice = "rock"
    elif computer_input == 2:
        computer_choice = "paper"
    elif computer_input == 3:
        computer_choice = "scissors"
        
    print(f"Computer picked {computer_choice}.") 
    
    # Game code checking
    if user_choice == "rock" and computer_choice == "scissors":
        print("You won!")
        user_wins += 1
    elif user_choice == "paper" and computer_choice == "rock":
        print("You won!")
        user_wins += 1
    elif user_choice == "scissors" and computer_choice == "paper":
        print("You won!")
        user_wins += 1
    else:
        print("You lost!")
        computer_wins += 1

print("*"*10, "Goodbye!", "*"*10)
print(f"You : {user_wins} | Computer : {computer_wins}".center(30))
print("*"*30)