import streamlit as st
from openai import OpenAI

def generate_story(theme, genre, characters, length_preference="medium"):
    """
    Generates an English story using the OpenAI API configured for OpenRouter,
    based on provided theme, genre, characters, and length preference.
    """
    # Initialize the OpenAI client with the specified base URL and API key
    # IMPORTANT: In a real application, use st.secrets for your API key:
    # client = OpenAI(
    #     base_url="https://openrouter.ai/api/v1",
    #     api_key=st.secrets["OPENROUTER_API_KEY"],
    # )
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key="sk-or-v1-YOUR_OPENROUTER_API_KEY_HERE", # REPLACE WITH YOUR ACTUAL API KEY OR USE st.secrets
    )

    # Determine desired story length based on user preference
    if length_preference == "short":
        length_guidance = "approximately 300-500 words (about 1-2 paragraphs for each plot point)."
    elif length_preference == "long":
        length_guidance = "approximately 1000-1500 words (rich detail and multiple sub-plots if applicable)."
    else: # medium
        length_guidance = "approximately 500-1000 words (moderate detail with a clear beginning, middle, and end)."

    # Define the system prompt to instruct the AI to act as a storyteller.
    # This prompt guides the model on the desired output format, style, and tone.
    story_prompt = f"""
    You are a highly creative and engaging storyteller. Your task is to write an original and compelling story
    based on the following parameters provided by the user.

    *Story Guidelines:*
    - The story should be in **English**.
    - **Theme**: "{theme}"
    - **Genre**: "{genre}"
    - **Main Characters**: "{characters}"
    - The story should have a clear **beginning, rising action, climax, falling action, and resolution**.
    - Focus on developing the characters, setting, and plot in an interesting way.
    - Aim for a narrative style appropriate for the chosen genre.
    - The story should be **{length_guidance}** in length.
    - Be imaginative and ensure the narrative flows naturally and logically.

    ---
    Begin the story now:
    """

    try:
        completion = client.chat.completions.create(
            extra_headers={},
            extra_body={},
            model="mistralai/mistral-small-3.2-24b-instruct:free", # You can experiment with other models
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": story_prompt
                        }
                    ]
                }
            ],
            temperature=0.9, # Higher temperature for more creativity in storytelling
            max_tokens=2000 # Set a higher max token limit for stories
        )
        story_text = completion.choices[0].message.content
        return story_text

    except Exception as e:
        st.error(f"An error occurred: {e}")
        return "Failed to generate a story. Please try again."


# Streamlit UI setup
st.set_page_config(page_title="Creative Story Generator", layout="centered")

st.header("✨ Creative Story Generator")
st.markdown("Unleash your imagination! Tell me your story's **theme, genre, and main characters**, and I'll write a tale just for you.")

# User inputs for story generation
story_theme = st.text_input(
    "What is the **main theme** of your story?",
    placeholder="e.g., 'Overcoming adversity', 'The power of friendship', 'A quest for ancient treasure'"
)

story_genre = st.selectbox(
    "Choose the **genre** for your story:",
    ('Fantasy', 'Science Fiction', 'Mystery', 'Romance', 'Thriller', 'Historical Fiction', 'Adventure', 'Horror', 'Slice of Life', 'Other'),
    index=0 # Default to Fantasy
)

story_characters = st.text_area(
    "Describe the **main characters** (e.g., 'A cynical detective and her eager rookie partner', 'A young wizard burdened by a prophecy', 'An AI exploring human emotions'):",
    height=80,
    placeholder="Example: 'A brave knight and a mischievous dragon.'"
)

# Slider for story length preference
length_option = st.radio(
    "How **long** should your story be?",
    ('Short (300-500 words)', 'Medium (500-1000 words)', 'Long (1000-1500 words)'),
    index=1 # Medium by default
)

# Convert display text to internal value
if "Short" in length_option:
    selected_length = "short"
elif "Long" in length_option:
    selected_length = "long"
else:
    selected_length = "medium"

# Button to trigger story generation
if st.button("Generate My Story 📖", help="Click to generate your custom story"):
    if story_theme and story_genre and story_characters:
        with st.spinner("Crafting your epic tale... Please wait."):
            generated_story = generate_story(story_theme, story_genre, story_characters, selected_length)

            st.subheader("🎉 Your Generated Story")
            st.write(generated_story)

            st.markdown(
                """
                ---
                <small>Hope you enjoyed your journey into the narrative!</small>
                """,
                unsafe_allow_html=True
            )
    else:
        st.warning("Please fill in the **Theme**, **Genre**, and **Main Characters** to generate your story.")