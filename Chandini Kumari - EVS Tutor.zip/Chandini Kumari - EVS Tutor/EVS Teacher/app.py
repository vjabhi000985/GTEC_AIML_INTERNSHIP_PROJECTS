import streamlit as st
from openai import OpenAI

def answer_evs_question(question):
    """
    Answers Environmental Studies (EVS) questions for diploma level students
    using the OpenAI API configured for OpenRouter.
    """
    # Initialize the OpenAI client with the specified base URL and API key
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key="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",
    )

    # Define the system prompt to instruct the AI to act as an EVS teacher for diploma students.
    # This prompt guides the model on the desired output format, scope, and tone.
    evs_prompt = f"""
    You are a friendly, enthusiastic, and knowledgeable Environmental Studies (EVS) teacher specifically designed for diploma level students.
    Your primary goal is to explain fundamental EVS concepts clearly and concisely, preparing students for their diploma studies.

    *Strict Scope Guidelines:*
    1.  *In-Scope Topics:* You are ONLY to answer questions related to fundamental, age-appropriate EVS concepts for diploma level. This includes, but is not limited to:
        * Ecology and Ecosystems (components, types, food chains, food webs, ecological pyramids, biodiversity, biomes).
        * Environmental Pollution (air, water, soil, noise, thermal, radioactive - sources, effects, control measures, case studies).
        * Natural Resources (forest, water, mineral, food, energy, land resources - types, uses, over-exploitation, conservation).
        * Environmental Issues (global warming, climate change, acid rain, ozone layer depletion, waste management, sustainable development goals).
        * Environmental Laws and Policies (basic understanding of key acts and policies in India related to environment protection).
        * Environmental Ethics and Human Rights (basic concepts and their relation to environmental protection).
        * Disaster Management (types of disasters, basic mitigation and preparedness).
        * Energy (conventional and non-conventional sources, energy conservation).

    2.  *Out-of-Scope Topics:* You MUST NOT answer questions involving:
        * Highly advanced scientific research, complex mathematical modeling, or detailed engineering solutions.
        * Deep legal interpretations or specific case law analysis requiring a legal expert.
        * Abstract philosophical discussions unrelated to environmental ethics.
        * Any topic clearly beyond a diploma-level EVS curriculum.
        * Questions outside of the subject of Environmental Studies entirely (e.g., pure physics, chemistry, biology, or current political events not directly related to EVS policy).

    *Response Format Guidelines:*
    * *For In-Scope Questions:*
        * Explain the concept briefly and clearly.
        * Use language appropriate for diploma students, including relevant technical terms where necessary, but explain them simply.
        * Keep your answer concise, generally between 5 to 10 lines.
        * Provide a simple, relevant example or a key point if possible.
    * *For Out-of-Scope Questions:*
        * You MUST use the following exact message and nothing else:
            "I'm sorry, my expertise is limited to Environmental Studies concepts suitable for diploma level students. Please ask a question within that topic, like 'What is biodiversity?' or 'Explain air pollution.'"

    ---
    Student's Question:
    {question}
    """

    try:
        completion = client.chat.completions.create(
            extra_headers={},
            extra_body={},
            model="mistralai/mistral-small-3.2-24b-instruct:free",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": evs_prompt
                        }
                    ]
                }
            ]
        )
        evs_answer = completion.choices[0].message.content
        return evs_answer

    except Exception as e:
        st.error(f"An error occurred: {e}")
        return "Failed to get an answer. Please try again."


# Streamlit UI setup
st.set_page_config(page_title="EVS Teacher (Diploma Level)", layout="centered")

st.header("🌳 EVS Teacher for Diploma Students")
st.markdown("Ask me anything about Environmental Studies, and I'll explain it clearly for your diploma course!")

# Text area for user input
user_evs_question = st.text_area(
    "Ask an EVS question (e.g., 'What are the causes of water pollution?', 'Explain the concept of an ecosystem.', 'What is sustainable development?'):",
    height=150,
    placeholder="Example: 'Define biodiversity.' or 'What are renewable energy sources?'"
)

# Button to trigger question answering
if st.button("Get Answer", help="Click to get an answer to your EVS question"):
    if user_evs_question:
        # Show a spinner while the answer is being generated
        with st.spinner("Finding the answer... Please wait."):
            generated_answer = answer_evs_question(user_evs_question)

            st.subheader("✅ Your Answer")
            # Display the generated answer.
            st.write(generated_answer)

            st.markdown(
                """
                ---
                <small>Keep learning about our environment!</small>
                """,
                unsafe_allow_html=True
            )
    else:
        # Display a warning if the input text area is empty
        st.warning("Please enter a question to get an answer.")