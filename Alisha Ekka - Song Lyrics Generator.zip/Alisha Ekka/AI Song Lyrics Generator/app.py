import streamlit as st
from openai import OpenAI

def generate_song(keywords_or_sentence):
    """
    Generates a song based on keywords or a sentence using the OpenAI API
    configured for OpenRouter.
    """
    # Initialize the OpenAI client with the specified base URL and API key
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key="your api key"
    )

    # Define the system prompt to instruct the AI to act as a song generator.
    # This prompt guides the model on the desired output format and content.
    song_prompt = f"""
    You are a creative song lyricist. Your task is to generate a short, simple, and catchy song
    in English, suitable for all ages. The song should be based on the following keywords or sentence.

    Please structure the song with at least two verses and a chorus.

    ---
    User's Input:
    {keywords_or_sentence}
    """

    # Make the API call to generate content.
    # The model used is 'mistralai/mistral-small-3.2-24b-instruct:free' as specified by the user.
    completion = client.chat.completions.create(
        extra_headers={
            # Optional headers for OpenRouter.ai, commented out by default.
            # "HTTP-Referer": "<YOUR_SITE_URL>",
            # "X-Title": "<YOUR_SITE_NAME>",
        },
        extra_body={},
        model="mistralai/mistral-small-3.2-24b-instruct:free",
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": song_prompt
                    }
                ]
            }
        ]
    )

    # Return the generated song lyrics from the model's response.
    return completion.choices[0].message.content

# Streamlit UI setup
st.set_page_config(page_title="Song Generator", layout="centered")

st.header("🎶 English Song Generator")
st.markdown("Enter some keywords or a sentence, and I'll generate a catchy song for you!")

# Text area for user input
user_input_for_song = st.text_area(
    "Enter keywords or a sentence (e.g., 'sunny day, happy dog, playing in the park' or 'adventure in space'):",
    height=150,
    placeholder="Example: 'Friendship and fun' or 'Exploring the forest'"
)

# Button to trigger song generation
if st.button("Generate Song", help="Click to generate a song based on your input"):
    if user_input_for_song:
        # Show a spinner while the song is being generated
        with st.spinner("Generating your song... Please wait."):
            generated_lyrics = generate_song(user_input_for_song)

            st.subheader("✅ Your Generated Song")
            # Display the generated lyrics. Using st.write will render markdown correctly.
            st.write(generated_lyrics)

            st.markdown(
                """
                ---
                <small>Hope you enjoyed your new song!</small>
                """,
                unsafe_allow_html=True
            )
    else:
        # Display a warning if the input text area is empty
        st.warning("Please enter some keywords or a sentence to generate a song.")
