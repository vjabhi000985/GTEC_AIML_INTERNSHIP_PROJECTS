import streamlit as st
from openai import OpenAI

def answer_history_question(question):
    """
    Answers History questions for diploma-level students
    using the OpenAI API configured for OpenRouter.
    """
    # Initialize the OpenAI client with the specified base URL and API key
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key="your api key", # This API key should ideally be stored securely
    )

    # Define the system prompt to instruct the AI to act as a History teacher for diploma students.
    # This prompt guides the model on the desired output format, scope, and tone.
    history_prompt = f"""
    You are a friendly, enthusiastic, and knowledgeable History teacher specifically designed for diploma level students.
    Your primary goal is to explain fundamental historical concepts, events, and figures clearly and concisely, preparing students for their diploma studies.

    *Strict Scope Guidelines:*
    1.  *In-Scope Topics:* You are ONLY to answer questions related to fundamental, age-appropriate History concepts for diploma level. This includes, but is not limited to:
        * Ancient Civilizations (e.g., Indus Valley, Egyptian, Mesopotamian, Greek, Roman - key features, achievements, decline).
        * Medieval History (e.g., European feudalism, Islamic Golden Age, major empires like Mughal, Ottoman - significant events, cultural contributions).
        * Modern History (e.g., Renaissance, Reformation, Age of Exploration, Industrial Revolution, World Wars, Cold War, major independence movements - causes, impacts, key figures).
        * Indian History (ancient, medieval, modern - major dynasties, socio-political structures, cultural developments, freedom struggle).
        * Key Historical Concepts (e.g., colonialism, imperialism, nationalism, revolutions, democracy, communism, fascism).
        * Significant historical figures and their contributions.

    2.  *Out-of-Scope Topics:* You MUST NOT answer questions involving:
        * Highly detailed academic research, complex historiographical debates, or in-depth historical methodology requiring a university-level expert.
        * Deep political analysis of current events or speculative future predictions.
        * Abstract philosophical discussions unrelated to historical context.
        * Any topic clearly beyond a diploma-level History curriculum.
        * Questions outside of the subject of History entirely (e.g., pure science, mathematics, literature analysis, or current sports events).

    *Response Format Guidelines:*
    * *For In-Scope Questions:*
        * Explain the concept, event, or figure briefly and clearly.
        * Use language appropriate for diploma students, including relevant historical terms where necessary, but explain them simply.
        * Keep your answer concise, generally between 5 to 10 lines.
        * Provide a simple, relevant example or a key point if possible.
    * *For Out-of-Scope Questions:*
        * You MUST use the following exact message and nothing else:
            "I'm sorry, my expertise is limited to History concepts suitable for diploma level students. Please ask a question within that topic, like 'Who was Mahatma Gandhi?' or 'Explain the causes of World War I.'"

    ---
    Student's Question:
    {question}
    """

    try:
        completion = client.chat.completions.create(
            extra_headers={},
            extra_body={},
            model="mistralai/mistral-small-3.2-24b-instruct:free",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {
                            "type": "text",
                            "text": history_prompt
                        }
                    ]
                }
            ]
        )
        history_answer = completion.choices[0].message.content
        return history_answer

    except Exception as e:
        st.error(f"An error occurred: {e}")
        return "Failed to get an answer. Please try again."


# Streamlit UI setup
st.set_page_config(page_title="History Teacher (Diploma Level)", layout="centered")

st.header("🏛️ History Teacher for Diploma Students")
st.markdown("Ask me anything about History, and I'll explain it clearly for your diploma course!")

# Text area for user input
user_history_question = st.text_area(
    "Ask a History question (e.g., 'What was the significance of the French Revolution?', 'Who was Ashoka?', 'Explain the causes of the Cold War?'):",
    height=150,
    placeholder="Example: 'Define feudalism.' or 'What was the impact of the Industrial Revolution?'"
)

# Button to trigger question answering
if st.button("Get Answer", help="Click to get an answer to your History question"):
    if user_history_question:
        # Show a spinner while the answer is being generated
        with st.spinner("Finding the answer... Please wait."):
            generated_answer = answer_history_question(user_history_question)

            st.subheader("✅ Your Answer")
            # Display the generated answer.
            st.write(generated_answer)

            st.markdown(
                """
                ---
                <small>Keep exploring the past!</small>
                """,
                unsafe_allow_html=True
            )
    else:
        # Display a warning if the input text area is empty
        st.warning("Please enter a question to get an answer.")